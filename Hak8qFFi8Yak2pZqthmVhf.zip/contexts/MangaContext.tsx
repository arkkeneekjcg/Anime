import React, { createContext, ReactNode } from 'react';
import { Manga, Chapter, AdminStats } from '../types';

interface MangaContextType {
  mangas: Manga[];
  loading: boolean;
  currentManga: Manga | null;
  currentChapter: Chapter | null;
  refreshMangas: () => Promise<void>;
  getMangaById: (id: string) => Promise<void>;
  getChapter: (mangaId: string, chapterNumber: number) => Promise<void>;
  addManga: (manga: Omit<Manga, 'id' | 'createdAt' | 'updatedAt'>) => Promise<boolean>;
  updateManga: (id: string, updates: Partial<Manga>) => Promise<boolean>;
  deleteManga: (id: string) => Promise<boolean>;
  addChapter: (mangaId: string, chapter: Omit<Chapter, 'id' | 'mangaId'>) => Promise<boolean>;
  getAdminStats: () => Promise<AdminStats>;
}

export const MangaContext = createContext<MangaContextType | undefined>(undefined);

interface MangaProviderProps {
  children: ReactNode;
}

export const MangaProvider: React.FC<MangaProviderProps> = ({ children }) => {
  // This provider only creates context, actual logic is in useManga hook
  const contextValue: MangaContextType = {
    mangas: [],
    loading: true,
    currentManga: null,
    currentChapter: null,
    refreshMangas: async () => {},
    getMangaById: async () => {},
    getChapter: async () => {},
    addManga: async () => false,
    updateManga: async () => false,
    deleteManga: async () => false,
    addChapter: async () => false,
    getAdminStats: async () => ({ totalMangas: 0, totalUsers: 0, premiumUsers: 0, totalChapters: 0 })
  };

  return (
    <MangaContext.Provider value={contextValue}>
      {children}
    </MangaContext.Provider>
  );
};