import React, { createContext, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateSubscription: (subscriptionType: 'free' | 'premium') => Promise<boolean>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // This provider only creates context, actual logic is in useAuth hook
  const contextValue: AuthContextType = {
    user: null,
    loading: true,
    login: async () => false,
    logout: async () => {},
    updateSubscription: async () => false
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};