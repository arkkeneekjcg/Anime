export const ADMIN_CREDENTIALS = {
  email: 'aydosshankulov37@gmail.com',
  password: 'arkenyo0982'
};

export const SUBSCRIPTION_PLANS = [
  {
    type: 'free' as const,
    name: 'Bepul',
    price: 0,
    duration: 'Abadiy',
    features: [
      'Cheklangan manga katalogi',
      'Reklama bilan',
      'Asosiy o\'qish funksiyalari',
      'Faqat bepul chapterlar'
    ]
  },
  {
    type: 'premium' as const,
    name: 'Premium',
    price: 50000,
    duration: 'Oylik',
    features: [
      'Barcha manga katalogi',
      'Reklamasiz tajriba',
      'Offline o\'qish',
      'Premium chapterlar',
      'HD sifat',
      'Yangi chapterlar birinchi bo\'lib'
    ]
  }
];

export const SAMPLE_GENRES = [
  'Action', 'Romance', 'Comedy', 'Drama', 'Fantasy', 
  'Horror', 'Sci-Fi', 'Slice of Life', 'Adventure', 'Mystery'
];

export const Colors = {
  primary: '#FF6B6B',
  secondary: '#4ECDC4',
  background: '#F8F9FA',
  surface: '#FFFFFF',
  text: '#2C3E50',
  textSecondary: '#7F8C8D',
  accent: '#FFD93D',
  error: '#E74C3C',
  success: '#2ECC71',
  warning: '#F39C12',
  premium: '#8E44AD',
  admin: '#E67E22'
};