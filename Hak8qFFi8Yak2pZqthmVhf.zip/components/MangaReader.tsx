import React, { useState, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Dimensions,
  SafeAreaView 
} from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Chapter } from '../types';
import { Colors } from '../constants';

interface MangaReaderProps {
  chapter: Chapter;
  onPreviousChapter?: () => void;
  onNextChapter?: () => void;
  onClose: () => void;
  hasPreviousChapter?: boolean;
  hasNextChapter?: boolean;
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export const MangaReader: React.FC<MangaReaderProps> = ({
  chapter,
  onPreviousChapter,
  onNextChapter,
  onClose,
  hasPreviousChapter = false,
  hasNextChapter = false
}) => {
  const insets = useSafeAreaInsets();
  const [currentPage, setCurrentPage] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const flatListRef = useRef<FlatList>(null);

  const handlePageChange = ({ viewableItems }: any) => {
    if (viewableItems.length > 0) {
      setCurrentPage(viewableItems[0].index);
    }
  };

  const toggleControls = () => {
    setShowControls(!showControls);
  };

  const goToPage = (pageIndex: number) => {
    flatListRef.current?.scrollToIndex({ index: pageIndex, animated: true });
  };

  const renderPage = ({ item, index }: { item: string; index: number }) => (
    <TouchableOpacity 
      style={styles.pageContainer} 
      onPress={toggleControls}
      activeOpacity={1}
    >
      <Image 
        source={{ uri: item }} 
        style={styles.pageImage}
        contentFit="contain"
      />
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      {showControls && (
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.headerButton}>
            <MaterialIcons name="close" size={24} color={Colors.surface} />
          </TouchableOpacity>
          
          <View style={styles.headerCenter}>
            <Text style={styles.chapterTitle} numberOfLines={1}>
              {chapter.title}
            </Text>
            <Text style={styles.pageIndicator}>
              {currentPage + 1} / {chapter.pages.length}
            </Text>
          </View>
          
          <TouchableOpacity style={styles.headerButton}>
            <MaterialIcons name="more-vert" size={24} color={Colors.surface} />
          </TouchableOpacity>
        </View>
      )}

      {/* Page Content */}
      <FlatList
        ref={flatListRef}
        data={chapter.pages}
        renderItem={renderPage}
        keyExtractor={(_, index) => index.toString()}
        horizontal={false}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={handlePageChange}
        viewabilityConfig={{
          itemVisiblePercentThreshold: 50
        }}
        style={styles.pagesList}
      />

      {/* Bottom Controls */}
      {showControls && (
        <View style={[styles.bottomControls, { paddingBottom: insets.bottom }]}>
          <TouchableOpacity 
            style={[styles.controlButton, !hasPreviousChapter && styles.disabledButton]}
            onPress={onPreviousChapter}
            disabled={!hasPreviousChapter}
          >
            <MaterialIcons 
              name="skip-previous" 
              size={24} 
              color={hasPreviousChapter ? Colors.surface : Colors.textSecondary} 
            />
            <Text style={[
              styles.controlButtonText, 
              !hasPreviousChapter && styles.disabledButtonText
            ]}>
              Oldingi
            </Text>
          </TouchableOpacity>

          <View style={styles.pageNavigation}>
            <TouchableOpacity 
              style={styles.pageButton}
              onPress={() => currentPage > 0 && goToPage(currentPage - 1)}
              disabled={currentPage === 0}
            >
              <MaterialIcons 
                name="keyboard-arrow-left" 
                size={20} 
                color={currentPage === 0 ? Colors.textSecondary : Colors.surface} 
              />
            </TouchableOpacity>
            
            <Text style={styles.pageText}>
              {currentPage + 1}
            </Text>
            
            <TouchableOpacity 
              style={styles.pageButton}
              onPress={() => currentPage < chapter.pages.length - 1 && goToPage(currentPage + 1)}
              disabled={currentPage === chapter.pages.length - 1}
            >
              <MaterialIcons 
                name="keyboard-arrow-right" 
                size={20} 
                color={currentPage === chapter.pages.length - 1 ? Colors.textSecondary : Colors.surface} 
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={[styles.controlButton, !hasNextChapter && styles.disabledButton]}
            onPress={onNextChapter}
            disabled={!hasNextChapter}
          >
            <MaterialIcons 
              name="skip-next" 
              size={24} 
              color={hasNextChapter ? Colors.surface : Colors.textSecondary} 
            />
            <Text style={[
              styles.controlButtonText, 
              !hasNextChapter && styles.disabledButtonText
            ]}>
              Keyingi
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  headerButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 16,
  },
  chapterTitle: {
    color: Colors.surface,
    fontSize: 16,
    fontWeight: 'bold',
  },
  pageIndicator: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    marginTop: 2,
  },
  pagesList: {
    flex: 1,
  },
  pageContainer: {
    width: SCREEN_WIDTH,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  pageImage: {
    width: SCREEN_WIDTH,
    height: '100%',
  },
  bottomControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  controlButton: {
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  disabledButton: {
    opacity: 0.5,
  },
  controlButtonText: {
    color: Colors.surface,
    fontSize: 12,
    marginTop: 4,
  },
  disabledButtonText: {
    color: Colors.textSecondary,
  },
  pageNavigation: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    paddingHorizontal: 8,
  },
  pageButton: {
    padding: 8,
  },
  pageText: {
    color: Colors.surface,
    fontSize: 14,
    fontWeight: 'bold',
    marginHorizontal: 12,
    minWidth: 30,
    textAlign: 'center',
  },
});