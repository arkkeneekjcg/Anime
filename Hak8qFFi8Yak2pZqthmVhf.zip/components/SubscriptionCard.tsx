import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Subscription } from '../types';
import { Colors } from '../constants';

interface SubscriptionCardProps {
  subscription: Subscription;
  isActive: boolean;
  onSelect: () => void;
}

export const SubscriptionCard: React.FC<SubscriptionCardProps> = ({ 
  subscription, 
  isActive, 
  onSelect 
}) => {
  return (
    <TouchableOpacity 
      style={[
        styles.container, 
        isActive && styles.activeContainer,
        subscription.type === 'premium' && styles.premiumContainer
      ]} 
      onPress={onSelect}
    >
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={[styles.title, isActive && styles.activeTitle]}>
            {subscription.name}
          </Text>
          {subscription.type === 'premium' && (
            <MaterialIcons 
              name="star" 
              size={20} 
              color={Colors.accent} 
              style={styles.starIcon}
            />
          )}
        </View>
        
        <View style={styles.priceContainer}>
          <Text style={[styles.price, isActive && styles.activePrice]}>
            {subscription.price === 0 ? 'Bepul' : `${subscription.price.toLocaleString()} so'm`}
          </Text>
          <Text style={[styles.duration, isActive && styles.activeDuration]}>
            {subscription.duration}
          </Text>
        </View>
      </View>

      <View style={styles.features}>
        {subscription.features.map((feature, index) => (
          <View key={index} style={styles.featureItem}>
            <MaterialIcons 
              name="check" 
              size={16} 
              color={isActive ? Colors.surface : Colors.success} 
            />
            <Text style={[styles.featureText, isActive && styles.activeFeatureText]}>
              {feature}
            </Text>
          </View>
        ))}
      </View>

      {isActive && (
        <View style={styles.activeBadge}>
          <MaterialIcons name="check-circle" size={16} color={Colors.surface} />
          <Text style={styles.activeBadgeText}>Joriy tarif</Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  activeContainer: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary,
  },
  premiumContainer: {
    borderColor: Colors.premium,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
  },
  activeTitle: {
    color: Colors.surface,
  },
  starIcon: {
    marginLeft: 8,
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  activePrice: {
    color: Colors.surface,
  },
  duration: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  activeDuration: {
    color: 'rgba(255,255,255,0.8)',
  },
  features: {
    marginBottom: 12,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    color: Colors.text,
    marginLeft: 8,
    flex: 1,
  },
  activeFeatureText: {
    color: Colors.surface,
  },
  activeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginTop: 8,
  },
  activeBadgeText: {
    color: Colors.surface,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});