import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons } from '@expo/vector-icons';
import { Manga } from '../types';
import { Colors } from '../constants';

interface MangaCardProps {
  manga: Manga;
  onPress: () => void;
  isPremium?: boolean;
}

export const MangaCard: React.FC<MangaCardProps> = ({ manga, onPress, isPremium = false }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.imageContainer}>
        <Image 
          source={{ uri: manga.cover }} 
          style={styles.image}
          contentFit="cover"
        />
        {manga.isPremium && !isPremium && (
          <View style={styles.premiumBadge}>
            <MaterialIcons name="star" size={16} color={Colors.accent} />
          </View>
        )}
        <View style={styles.ratingBadge}>
          <MaterialIcons name="star" size={12} color={Colors.accent} />
          <Text style={styles.ratingText}>{manga.rating}</Text>
        </View>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={2}>{manga.title}</Text>
        <Text style={styles.author} numberOfLines={1}>{manga.author}</Text>
        
        <View style={styles.genreContainer}>
          {manga.genre.slice(0, 2).map((genre, index) => (
            <View key={index} style={styles.genreTag}>
              <Text style={styles.genreText}>{genre}</Text>
            </View>
          ))}
        </View>
        
        <View style={styles.footer}>
          <View style={styles.statusContainer}>
            <MaterialIcons 
              name={manga.status === 'ongoing' ? 'trending-up' : 'check-circle'} 
              size={14} 
              color={manga.status === 'ongoing' ? Colors.success : Colors.textSecondary} 
            />
            <Text style={[styles.statusText, { 
              color: manga.status === 'ongoing' ? Colors.success : Colors.textSecondary 
            }]}>
              {manga.status === 'ongoing' ? 'Davom etmoqda' : 'Tugallangan'}
            </Text>
          </View>
          
          <Text style={styles.chapterCount}>
            {manga.chapters.length} bob
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  imageContainer: {
    position: 'relative',
    height: 200,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  premiumBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: Colors.premium,
    borderRadius: 20,
    padding: 4,
  },
  ratingBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 12,
    paddingHorizontal: 6,
    paddingVertical: 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: Colors.surface,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 2,
  },
  content: {
    padding: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  author: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 8,
  },
  genreContainer: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  genreTag: {
    backgroundColor: Colors.background,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
    marginRight: 4,
  },
  genreText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    fontSize: 12,
    marginLeft: 4,
  },
  chapterCount: {
    fontSize: 12,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
});