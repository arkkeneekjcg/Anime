export interface User {
  id: string;
  email: string;
  username: string;
  subscriptionType: 'free' | 'premium';
  isAdmin: boolean;
  avatar?: string;
}

export interface Manga {
  id: string;
  title: string;
  description: string;
  cover: string;
  author: string;
  genre: string[];
  status: 'ongoing' | 'completed';
  isPremium: boolean;
  rating: number;
  chapters: Chapter[];
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  mangaId: string;
  title: string;
  chapterNumber: number;
  pages: string[];
  isPremium: boolean;
  publishedAt: string;
}

export interface Subscription {
  type: 'free' | 'premium';
  name: string;
  price: number;
  features: string[];
  duration: string;
}

export interface AdminStats {
  totalMangas: number;
  totalUsers: number;
  premiumUsers: number;
  totalChapters: number;
}