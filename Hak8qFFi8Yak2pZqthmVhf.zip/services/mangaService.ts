import AsyncStorage from '@react-native-async-storage/async-storage';
import { Manga, Chapter, AdminStats } from '../types';

// Sample manga data
const SAMPLE_MANGAS: Manga[] = [
  {
    id: '1',
    title: 'Tower of God',
    description: 'Baam is a young boy who had only known a small cave and an old woman until the day he meets Rachel, who was going to the Tower.',
    cover: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=400&fit=crop',
    author: 'SIU',
    genre: ['Action', 'Adventure', 'Fantasy'],
    status: 'ongoing',
    isPremium: false,
    rating: 4.8,
    chapters: [
      {
        id: 'ch-1-1',
        mangaId: '1',
        title: 'Ball',
        chapterNumber: 1,
        pages: [
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=350&h=600&fit=crop',
          'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=350&h=600&fit=crop',
          'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=350&h=600&fit=crop'
        ],
        isPremium: false,
        publishedAt: '2024-01-01'
      },
      {
        id: 'ch-1-2',
        mangaId: '1', 
        title: '3F',
        chapterNumber: 2,
        pages: [
          'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=350&h=600&fit=crop',
          'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=350&h=600&fit=crop',
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=350&h=600&fit=crop'
        ],
        isPremium: true,
        publishedAt: '2024-01-02'
      }
    ],
    createdAt: '2024-01-01',
    updatedAt: '2024-01-02'
  },
  {
    id: '2',
    title: 'Solo Leveling',
    description: 'Ten years ago, "the Gate" appeared and connected the real world with the realm of magic and monsters.',
    cover: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&h=400&fit=crop',
    author: 'Chugong',
    genre: ['Action', 'Fantasy'],
    status: 'completed',
    isPremium: true,
    rating: 4.9,
    chapters: [
      {
        id: 'ch-2-1',
        mangaId: '2',
        title: 'I\'m Used to It',
        chapterNumber: 1,
        pages: [
          'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=350&h=600&fit=crop',
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=350&h=600&fit=crop'
        ],
        isPremium: true,
        publishedAt: '2024-01-01'
      }
    ],
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01'
  }
];

export const mangaService = {
  async getAllMangas(): Promise<Manga[]> {
    try {
      const stored = await AsyncStorage.getItem('mangas');
      return stored ? JSON.parse(stored) : SAMPLE_MANGAS;
    } catch (error) {
      console.error('Get all mangas error:', error);
      return SAMPLE_MANGAS;
    }
  },

  async getMangaById(id: string): Promise<Manga | null> {
    try {
      const mangas = await this.getAllMangas();
      return mangas.find(m => m.id === id) || null;
    } catch (error) {
      console.error('Get manga by id error:', error);
      return null;
    }
  },

  async getChapter(mangaId: string, chapterNumber: number): Promise<Chapter | null> {
    try {
      const manga = await this.getMangaById(mangaId);
      return manga?.chapters.find(c => c.chapterNumber === chapterNumber) || null;
    } catch (error) {
      console.error('Get chapter error:', error);
      return null;
    }
  },

  async addManga(manga: Omit<Manga, 'id' | 'createdAt' | 'updatedAt'>): Promise<boolean> {
    try {
      const mangas = await this.getAllMangas();
      const newManga: Manga = {
        ...manga,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const updatedMangas = [...mangas, newManga];
      await AsyncStorage.setItem('mangas', JSON.stringify(updatedMangas));
      return true;
    } catch (error) {
      console.error('Add manga error:', error);
      return false;
    }
  },

  async updateManga(id: string, updates: Partial<Manga>): Promise<boolean> {
    try {
      const mangas = await this.getAllMangas();
      const index = mangas.findIndex(m => m.id === id);
      
      if (index === -1) return false;
      
      mangas[index] = {
        ...mangas[index],
        ...updates,
        updatedAt: new Date().toISOString()
      };
      
      await AsyncStorage.setItem('mangas', JSON.stringify(mangas));
      return true;
    } catch (error) {
      console.error('Update manga error:', error);
      return false;
    }
  },

  async deleteManga(id: string): Promise<boolean> {
    try {
      const mangas = await this.getAllMangas();
      const filteredMangas = mangas.filter(m => m.id !== id);
      await AsyncStorage.setItem('mangas', JSON.stringify(filteredMangas));
      return true;
    } catch (error) {
      console.error('Delete manga error:', error);
      return false;
    }
  },

  async addChapter(mangaId: string, chapter: Omit<Chapter, 'id' | 'mangaId'>): Promise<boolean> {
    try {
      const mangas = await this.getAllMangas();
      const mangaIndex = mangas.findIndex(m => m.id === mangaId);
      
      if (mangaIndex === -1) return false;
      
      const newChapter: Chapter = {
        ...chapter,
        id: Date.now().toString(),
        mangaId
      };
      
      mangas[mangaIndex].chapters.push(newChapter);
      mangas[mangaIndex].updatedAt = new Date().toISOString();
      
      await AsyncStorage.setItem('mangas', JSON.stringify(mangas));
      return true;
    } catch (error) {
      console.error('Add chapter error:', error);
      return false;
    }
  },

  async getAdminStats(): Promise<AdminStats> {
    try {
      const mangas = await this.getAllMangas();
      const totalChapters = mangas.reduce((acc, manga) => acc + manga.chapters.length, 0);
      
      return {
        totalMangas: mangas.length,
        totalUsers: 150, // Mock data
        premiumUsers: 45, // Mock data
        totalChapters
      };
    } catch (error) {
      console.error('Get admin stats error:', error);
      return {
        totalMangas: 0,
        totalUsers: 0,
        premiumUsers: 0,
        totalChapters: 0
      };
    }
  }
};