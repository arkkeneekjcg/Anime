import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';
import { ADMIN_CREDENTIALS } from '../constants';

export const authService = {
  async login(email: string, password: string): Promise<User | null> {
    try {
      // Admin login check
      if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
        const adminUser: User = {
          id: 'admin-1',
          email: ADMIN_CREDENTIALS.email,
          username: 'Admin',
          subscriptionType: 'premium',
          isAdmin: true,
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
        };
        await AsyncStorage.setItem('currentUser', JSON.stringify(adminUser));
        return adminUser;
      }

      // Regular user login (demo users)
      const demoUsers: User[] = [
        {
          id: 'user-1',
          email: 'user@example.com',
          username: 'Demo User',
          subscriptionType: 'free',
          isAdmin: false,
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b29c?w=100&h=100&fit=crop&crop=face'
        },
        {
          id: 'user-2', 
          email: 'premium@example.com',
          username: 'Premium User',
          subscriptionType: 'premium',
          isAdmin: false,
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
        }
      ];

      const user = demoUsers.find(u => u.email === email);
      if (user && password === '123456') {
        await AsyncStorage.setItem('currentUser', JSON.stringify(user));
        return user;
      }

      return null;
    } catch (error) {
      console.error('Login error:', error);
      return null;
    }
  },

  async logout(): Promise<void> {
    try {
      await AsyncStorage.removeItem('currentUser');
    } catch (error) {
      console.error('Logout error:', error);
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const userStr = await AsyncStorage.getItem('currentUser');
      return userStr ? JSON.parse(userStr) : null;
    } catch (error) {
      console.error('Get current user error:', error);
      return null;
    }
  },

  async updateSubscription(userId: string, subscriptionType: 'free' | 'premium'): Promise<boolean> {
    try {
      const userStr = await AsyncStorage.getItem('currentUser');
      if (userStr) {
        const user = JSON.parse(userStr);
        user.subscriptionType = subscriptionType;
        await AsyncStorage.setItem('currentUser', JSON.stringify(user));
        return true;
      }
      return false;
    } catch (error) {
      console.error('Update subscription error:', error);
      return false;
    }
  }
};