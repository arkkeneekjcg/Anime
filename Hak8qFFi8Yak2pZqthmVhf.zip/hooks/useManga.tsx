import { useState, useEffect, useContext } from 'react';
import { MangaContext } from '../contexts/MangaContext';
import { mangaService } from '../services/mangaService';
import { Manga, Chapter, AdminStats } from '../types';

export const useManga = () => {
  const context = useContext(MangaContext);
  if (!context) {
    throw new Error('useManga must be used within MangaProvider');
  }

  const [mangas, setMangas] = useState<Manga[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentManga, setCurrentManga] = useState<Manga | null>(null);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);

  useEffect(() => {
    refreshMangas();
  }, []);

  const refreshMangas = async (): Promise<void> => {
    try {
      setLoading(true);
      const allMangas = await mangaService.getAllMangas();
      setMangas(allMangas);
    } catch (error) {
      console.error('Refresh mangas error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMangaById = async (id: string): Promise<void> => {
    try {
      const manga = await mangaService.getMangaById(id);
      setCurrentManga(manga);
    } catch (error) {
      console.error('Get manga by id error:', error);
    }
  };

  const getChapter = async (mangaId: string, chapterNumber: number): Promise<void> => {
    try {
      const chapter = await mangaService.getChapter(mangaId, chapterNumber);
      setCurrentChapter(chapter);
    } catch (error) {
      console.error('Get chapter error:', error);
    }
  };

  const addManga = async (manga: Omit<Manga, 'id' | 'createdAt' | 'updatedAt'>): Promise<boolean> => {
    try {
      const success = await mangaService.addManga(manga);
      if (success) {
        await refreshMangas();
      }
      return success;
    } catch (error) {
      console.error('Add manga error:', error);
      return false;
    }
  };

  const updateManga = async (id: string, updates: Partial<Manga>): Promise<boolean> => {
    try {
      const success = await mangaService.updateManga(id, updates);
      if (success) {
        await refreshMangas();
        if (currentManga?.id === id) {
          const updatedManga = await mangaService.getMangaById(id);
          setCurrentManga(updatedManga);
        }
      }
      return success;
    } catch (error) {
      console.error('Update manga error:', error);
      return false;
    }
  };

  const deleteManga = async (id: string): Promise<boolean> => {
    try {
      const success = await mangaService.deleteManga(id);
      if (success) {
        await refreshMangas();
        if (currentManga?.id === id) {
          setCurrentManga(null);
        }
      }
      return success;
    } catch (error) {
      console.error('Delete manga error:', error);
      return false;
    }
  };

  const addChapter = async (mangaId: string, chapter: Omit<Chapter, 'id' | 'mangaId'>): Promise<boolean> => {
    try {
      const success = await mangaService.addChapter(mangaId, chapter);
      if (success) {
        await refreshMangas();
        if (currentManga?.id === mangaId) {
          const updatedManga = await mangaService.getMangaById(mangaId);
          setCurrentManga(updatedManga);
        }
      }
      return success;
    } catch (error) {
      console.error('Add chapter error:', error);
      return false;
    }
  };

  const getAdminStats = async (): Promise<AdminStats> => {
    try {
      return await mangaService.getAdminStats();
    } catch (error) {
      console.error('Get admin stats error:', error);
      return {
        totalMangas: 0,
        totalUsers: 0,
        premiumUsers: 0,
        totalChapters: 0
      };
    }
  };

  return {
    mangas,
    loading,
    currentManga,
    currentChapter,
    refreshMangas,
    getMangaById,
    getChapter,
    addManga,
    updateManga,
    deleteManga,
    addChapter,
    getAdminStats
  };
};