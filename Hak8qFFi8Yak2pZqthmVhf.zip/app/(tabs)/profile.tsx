import React, { useState, Platform } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  Alert,
  Modal
} from 'react-native';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../hooks/useAuth';
import { Colors } from '../../constants';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();
  
  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
    onCancel?: () => void;
    showCancel?: boolean;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void, onCancel?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ 
        visible: true, 
        title, 
        message, 
        onOk, 
        onCancel,
        showCancel: !!onCancel 
      });
    } else {
      const buttons = onCancel 
        ? [
            { text: 'Bekor qilish', onPress: onCancel },
            { text: 'OK', onPress: onOk }
          ]
        : [{ text: 'OK', onPress: onOk }];
      Alert.alert(title, message, buttons);
    }
  };

  const handleLogout = () => {
    showWebAlert(
      'Chiqish',
      'Hisobdan chiqishni xohlaysizmi?',
      async () => {
        await logout();
        router.replace('/login');
      },
      () => {} // Cancel handler
    );
  };

  const clearAppData = () => {
    showWebAlert(
      'Ma\'lumotlarni tozalash',
      'Barcha mahalliy ma\'lumotlar (sevimlilar, tarix) o\'chiriladi. Davom etasizmi?',
      async () => {
        try {
          await AsyncStorage.multiRemove(['favorites', 'readingHistory']);
          showWebAlert('Muvaffaqiyat', 'Ma\'lumotlar tozalandi');
        } catch (error) {
          showWebAlert('Xatolik', 'Ma\'lumotlarni tozalashda xatolik');
        }
      },
      () => {} // Cancel handler
    );
  };

  const profileStats = [
    {
      title: 'Obuna turi',
      value: user?.subscriptionType === 'premium' ? 'Premium' : 'Bepul',
      icon: user?.subscriptionType === 'premium' ? 'star' : 'person',
      color: user?.subscriptionType === 'premium' ? Colors.premium : Colors.textSecondary
    },
    {
      title: 'Foydalanuvchi turi',
      value: user?.isAdmin ? 'Admin' : 'Foydalanuvchi',
      icon: user?.isAdmin ? 'admin-panel-settings' : 'person',
      color: user?.isAdmin ? Colors.admin : Colors.textSecondary
    }
  ];

  const settingsOptions = [
    {
      title: 'Obuna sozlamalari',
      description: 'Obuna rejangizni ko\'ring va o\'zgartiring',
      icon: 'subscriptions',
      color: Colors.primary,
      onPress: () => router.push('/(tabs)/subscription')
    },
    {
      title: 'Bildirishnoma sozlamalari',
      description: 'Yangi chapterlar haqida xabar olish',
      icon: 'notifications',
      color: Colors.secondary,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    },
    {
      title: 'Mavzu sozlamalari',
      description: 'Qorong\'i yoki yorug\' mavzuni tanlang',
      icon: 'palette',
      color: Colors.accent,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    },
    {
      title: 'Ma\'lumotlarni tozalash',
      description: 'Mahalliy ma\'lumotlarni (sevimlilar, tarix) o\'chirish',
      icon: 'cleaning-services',
      color: Colors.warning,
      onPress: clearAppData
    },
    {
      title: 'Yordam',
      description: 'FAQ va qo\'llab-quvvatlash',
      icon: 'help',
      color: Colors.success,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    },
    {
      title: 'Ilova haqida',
      description: 'Versiya ma\'lumotlari va litsenziya',
      icon: 'info',
      color: Colors.textSecondary,
      onPress: () => showWebAlert('Ilova haqida', 'MangaReader v1.0.0\nOnSpace tomonidan yaratilgan')
    }
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profil</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color={Colors.error} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Profile Info */}
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            <Image 
              source={{ uri: user?.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face' }} 
              style={styles.avatar}
              contentFit="cover"
            />
            {user?.isAdmin && (
              <View style={styles.adminBadge}>
                <MaterialIcons name="admin-panel-settings" size={16} color={Colors.surface} />
              </View>
            )}
          </View>
          
          <Text style={styles.username}>{user?.username}</Text>
          <Text style={styles.email}>{user?.email}</Text>

          <View style={styles.statsContainer}>
            {profileStats.map((stat, index) => (
              <View key={index} style={styles.statItem}>
                <MaterialIcons name={stat.icon as any} size={20} color={stat.color} />
                <View style={styles.statText}>
                  <Text style={styles.statTitle}>{stat.title}</Text>
                  <Text style={[styles.statValue, { color: stat.color }]}>{stat.value}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Settings */}
        <View style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>Sozlamalar</Text>
          {settingsOptions.map((option, index) => (
            <TouchableOpacity key={index} style={styles.settingItem} onPress={option.onPress}>
              <View style={styles.settingLeft}>
                <View style={[styles.settingIcon, { backgroundColor: option.color + '20' }]}>
                  <MaterialIcons name={option.icon as any} size={24} color={option.color} />
                </View>
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>{option.title}</Text>
                  <Text style={styles.settingDescription}>{option.description}</Text>
                </View>
              </View>
              <MaterialIcons name="chevron-right" size={24} color={Colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <View style={styles.appInfo}>
            <MaterialIcons name="menu-book" size={32} color={Colors.primary} />
            <Text style={styles.appName}>MangaReader</Text>
            <Text style={styles.appVersion}>Versiya 1.0.0</Text>
            <Text style={styles.appCredit}>OnSpace tomonidan yaratilgan</Text>
          </View>
        </View>
      </ScrollView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.alertOverlay}>
            <View style={styles.alertContainer}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <View style={styles.alertButtons}>
                {alertConfig.showCancel && (
                  <TouchableOpacity 
                    style={[styles.alertButton, styles.cancelButton]}
                    onPress={() => {
                      alertConfig.onCancel?.();
                      setAlertConfig(prev => ({ ...prev, visible: false }));
                    }}
                  >
                    <Text style={styles.cancelButtonText}>Bekor qilish</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.surface,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  logoutButton: {
    padding: 8,
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    marginVertical: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  adminBadge: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    backgroundColor: Colors.admin,
    borderRadius: 12,
    padding: 4,
    borderWidth: 2,
    borderColor: Colors.surface,
  },
  username: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  email: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginBottom: 20,
  },
  statsContainer: {
    width: '100%',
    paddingHorizontal: 20,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.background,
  },
  statText: {
    marginLeft: 12,
    flex: 1,
  },
  statTitle: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 2,
  },
  settingsSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  appInfoSection: {
    marginTop: 20,
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: Colors.surface,
    borderRadius: 16,
  },
  appName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 12,
  },
  appVersion: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  appCredit: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 8,
  },
  // Web Alert Styles
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: Colors.text,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: Colors.text,
  },
  alertButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  alertButton: {
    backgroundColor: Colors.primary,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
    marginLeft: 8,
    minWidth: 80,
  },
  cancelButton: {
    backgroundColor: Colors.textSecondary,
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  cancelButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});