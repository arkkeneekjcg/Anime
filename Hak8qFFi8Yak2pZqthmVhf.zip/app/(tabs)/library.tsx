import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity,
  Alert,
  Modal,
  Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MangaCard } from '../../components/MangaCard';
import { useAuth } from '../../hooks/useAuth';
import { useManga } from '../../hooks/useManga';
import { Colors } from '../../constants';
import { Manga } from '../../types';

export default function LibraryScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { mangas } = useManga();
  
  const [favorites, setFavorites] = useState<string[]>([]);
  const [readingHistory, setReadingHistory] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'favorites' | 'history'>('favorites');
  
  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  useEffect(() => {
    loadLibraryData();
  }, []);

  const loadLibraryData = async () => {
    try {
      const favoritesData = await AsyncStorage.getItem('favorites');
      const historyData = await AsyncStorage.getItem('readingHistory');
      
      if (favoritesData) {
        setFavorites(JSON.parse(favoritesData));
      }
      
      if (historyData) {
        setReadingHistory(JSON.parse(historyData));
      }
    } catch (error) {
      console.error('Load library data error:', error);
    }
  };

  const toggleFavorite = async (mangaId: string) => {
    try {
      let updatedFavorites;
      if (favorites.includes(mangaId)) {
        updatedFavorites = favorites.filter(id => id !== mangaId);
        showWebAlert('', 'Sevimlilardan olib tashlandi');
      } else {
        updatedFavorites = [...favorites, mangaId];
        showWebAlert('', 'Sevimlilarga qo\'shildi');
      }
      
      setFavorites(updatedFavorites);
      await AsyncStorage.setItem('favorites', JSON.stringify(updatedFavorites));
    } catch (error) {
      console.error('Toggle favorite error:', error);
      showWebAlert('Xatolik', 'Sevimlilarni saqlashda xatolik');
    }
  };

  const clearHistory = async () => {
    try {
      setReadingHistory([]);
      await AsyncStorage.removeItem('readingHistory');
      showWebAlert('', 'O\'qish tarixi tozalandi');
    } catch (error) {
      console.error('Clear history error:', error);
      showWebAlert('Xatolik', 'Tarixni tozalashda xatolik');
    }
  };

  const getFavoriteMangas = (): Manga[] => {
    return mangas.filter(manga => favorites.includes(manga.id));
  };

  const getHistoryMangas = (): Manga[] => {
    return mangas.filter(manga => readingHistory.includes(manga.id));
  };

  const renderMangaCard = ({ item }: { item: Manga }) => (
    <View style={styles.mangaCardContainer}>
      <MangaCard
        manga={item}
        onPress={() => router.push(`/manga/${item.id}`)}
        isPremium={user?.subscriptionType === 'premium'}
      />
      {activeTab === 'favorites' && (
        <TouchableOpacity
          style={styles.favoriteButton}
          onPress={() => toggleFavorite(item.id)}
        >
          <MaterialIcons 
            name="favorite" 
            size={24} 
            color={Colors.primary} 
          />
        </TouchableOpacity>
      )}
    </View>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <MaterialIcons 
        name={activeTab === 'favorites' ? 'favorite-border' : 'history'} 
        size={64} 
        color={Colors.textSecondary} 
      />
      <Text style={styles.emptyTitle}>
        {activeTab === 'favorites' ? 'Sevimli mangalar yo\'q' : 'O\'qish tarixi bo\'sh'}
      </Text>
      <Text style={styles.emptySubtitle}>
        {activeTab === 'favorites' 
          ? 'Manga sahifasida yurak belgisini bosib sevimlilar ro\'yxatiga qo\'shing'
          : 'Mangalarni o\'qishni boshlang va tarix shu yerda ko\'rinadi'
        }
      </Text>
    </View>
  );

  const currentMangas = activeTab === 'favorites' ? getFavoriteMangas() : getHistoryMangas();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Kutubxona</Text>
        {activeTab === 'history' && readingHistory.length > 0 && (
          <TouchableOpacity onPress={clearHistory} style={styles.clearButton}>
            <MaterialIcons name="clear-all" size={24} color={Colors.primary} />
          </TouchableOpacity>
        )}
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'favorites' && styles.activeTab]}
          onPress={() => setActiveTab('favorites')}
        >
          <MaterialIcons 
            name="favorite" 
            size={20} 
            color={activeTab === 'favorites' ? Colors.surface : Colors.textSecondary} 
          />
          <Text style={[
            styles.tabText,
            activeTab === 'favorites' && styles.activeTabText
          ]}>
            Sevimlilar ({favorites.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'history' && styles.activeTab]}
          onPress={() => setActiveTab('history')}
        >
          <MaterialIcons 
            name="history" 
            size={20} 
            color={activeTab === 'history' ? Colors.surface : Colors.textSecondary} 
          />
          <Text style={[
            styles.tabText,
            activeTab === 'history' && styles.activeTabText
          ]}>
            Tarix ({readingHistory.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <FlatList
        data={currentMangas}
        renderItem={renderMangaCard}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        ListEmptyComponent={renderEmptyState}
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.alertOverlay}>
            <View style={styles.alertContainer}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.surface,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  clearButton: {
    padding: 8,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: Colors.surface,
    marginHorizontal: 4,
  },
  activeTab: {
    backgroundColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textSecondary,
    marginLeft: 8,
  },
  activeTabText: {
    color: Colors.surface,
  },
  list: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  mangaCardContainer: {
    position: 'relative',
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: Colors.surface,
    borderRadius: 20,
    padding: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 3.84,
    elevation: 5,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 20,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
    lineHeight: 20,
  },
  // Web Alert Styles
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: Colors.text,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: Colors.text,
  },
  alertButton: {
    backgroundColor: Colors.primary,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});