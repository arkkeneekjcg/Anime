import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity,
  TextInput,
  ScrollView
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MangaCard } from '../../components/MangaCard';
import { useAuth } from '../../hooks/useAuth';
import { useManga } from '../../hooks/useManga';
import { Colors, SAMPLE_GENRES } from '../../constants';
import { Manga } from '../../types';

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { mangas, loading } = useManga();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [filteredMangas, setFilteredMangas] = useState<Manga[]>([]);

  useEffect(() => {
    filterMangas();
  }, [mangas, searchQuery, selectedGenre, user]);

  const filterMangas = () => {
    let filtered = mangas;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(manga => 
        manga.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        manga.author.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by genre
    if (selectedGenre) {
      filtered = filtered.filter(manga => 
        manga.genre.includes(selectedGenre)
      );
    }

    // Filter by subscription for premium content
    if (user?.subscriptionType !== 'premium') {
      filtered = filtered.filter(manga => !manga.isPremium);
    }

    setFilteredMangas(filtered);
  };

  const renderGenreTag = ({ item }: { item: string }) => (
    <TouchableOpacity
      style={[
        styles.genreTag,
        selectedGenre === item && styles.selectedGenreTag
      ]}
      onPress={() => setSelectedGenre(selectedGenre === item ? null : item)}
    >
      <Text style={[
        styles.genreTagText,
        selectedGenre === item && styles.selectedGenreTagText
      ]}>
        {item}
      </Text>
    </TouchableOpacity>
  );

  const renderMangaCard = ({ item }: { item: Manga }) => (
    <MangaCard
      manga={item}
      onPress={() => router.push(`/manga/${item.id}`)}
      isPremium={user?.subscriptionType === 'premium'}
    />
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>
              Salom, {user?.username || 'Foydalanuvchi'}!
            </Text>
            <Text style={styles.subtitle}>
              {user?.subscriptionType === 'premium' ? 'Premium' : 'Bepul'} obuna
            </Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <MaterialIcons name="notifications" size={24} color={Colors.text} />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <MaterialIcons name="search" size={20} color={Colors.textSecondary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Manga qidirish..."
            placeholderTextColor={Colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <MaterialIcons name="clear" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Genre Filter */}
      <View style={styles.genreSection}>
        <Text style={styles.sectionTitle}>Janrlar</Text>
        <FlatList
          data={SAMPLE_GENRES}
          renderItem={renderGenreTag}
          keyExtractor={(item) => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.genreList}
        />
      </View>

      {/* Manga List */}
      <View style={styles.mangaSection}>
        <Text style={styles.sectionTitle}>
          {selectedGenre ? `${selectedGenre} janri` : 'Barcha mangalar'}
          {user?.subscriptionType !== 'premium' && ' (Bepul)'}
        </Text>
        
        {loading ? (
          <View style={styles.loadingContainer}>
            <MaterialIcons name="hourglass-empty" size={32} color={Colors.textSecondary} />
            <Text style={styles.loadingText}>Mangalar yuklanmoqda...</Text>
          </View>
        ) : (
          <FlatList
            data={filteredMangas}
            renderItem={renderMangaCard}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.mangaList}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <MaterialIcons name="search-off" size={48} color={Colors.textSecondary} />
                <Text style={styles.emptyTitle}>Manga topilmadi</Text>
                <Text style={styles.emptySubtitle}>
                  Boshqa kalit so'zlar bilan qidiring
                </Text>
              </View>
            }
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    backgroundColor: Colors.surface,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingTop: 16,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  notificationButton: {
    padding: 8,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.background,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: Colors.text,
    marginLeft: 8,
  },
  genreSection: {
    paddingVertical: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  genreList: {
    paddingHorizontal: 20,
  },
  genreTag: {
    backgroundColor: Colors.surface,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: Colors.background,
  },
  selectedGenreTag: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  genreTagText: {
    fontSize: 14,
    color: Colors.text,
    fontWeight: '500',
  },
  selectedGenreTagText: {
    color: Colors.surface,
  },
  mangaSection: {
    flex: 1,
    paddingTop: 8,
  },
  mangaList: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginTop: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
});