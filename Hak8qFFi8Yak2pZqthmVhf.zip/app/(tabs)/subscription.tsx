import React, { useState, Platform } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet,
  Alert,
  Modal,
  TouchableOpacity
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SubscriptionCard } from '../../components/SubscriptionCard';
import { useAuth } from '../../hooks/useAuth';
import { Colors, SUBSCRIPTION_PLANS } from '../../constants';

export default function SubscriptionScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateSubscription } = useAuth();
  const [loading, setLoading] = useState(false);
  
  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const handleSubscriptionChange = async (subscriptionType: 'free' | 'premium') => {
    if (user?.subscriptionType === subscriptionType) {
      return;
    }

    if (subscriptionType === 'premium') {
      showWebAlert(
        'Premium obuna',
        'Haqiqiy ilovada bu yerda to\'lov tizimi ishlab turadi. Demo versiyasida bepul premium beriladi.',
        async () => {
          setLoading(true);
          const success = await updateSubscription('premium');
          setLoading(false);
          
          if (success) {
            showWebAlert('Muvaffaqiyat!', 'Premium obunaga o\'tdingiz!');
          } else {
            showWebAlert('Xatolik', 'Obunani yangilashda xatolik yuz berdi');
          }
        }
      );
    } else {
      setLoading(true);
      const success = await updateSubscription('free');
      setLoading(false);
      
      if (success) {
        showWebAlert('', 'Bepul obunaga qaytdingiz');
      } else {
        showWebAlert('Xatolik', 'Obunani yangilashda xatolik yuz berdi');
      }
    }
  };

  const getPremiumFeatures = () => [
    'Barcha premium mangalar',
    'Reklamasiz o\'qish',
    'Offline yuklab olish',
    'HD sifat',
    'Yangi chapterlar birinchi',
    '24/7 qo\'llab-quvvatlash'
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Obuna rejasi</Text>
        <View style={styles.currentPlan}>
          <MaterialIcons 
            name={user?.subscriptionType === 'premium' ? 'star' : 'person'} 
            size={20} 
            color={user?.subscriptionType === 'premium' ? Colors.premium : Colors.textSecondary} 
          />
          <Text style={[
            styles.currentPlanText,
            { color: user?.subscriptionType === 'premium' ? Colors.premium : Colors.textSecondary }
          ]}>
            {user?.subscriptionType === 'premium' ? 'Premium' : 'Bepul'}
          </Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Premium Benefits */}
        <View style={styles.benefitsSection}>
          <Text style={styles.benefitsTitle}>Premium imtiyozlari</Text>
          <View style={styles.benefitsList}>
            {getPremiumFeatures().map((feature, index) => (
              <View key={index} style={styles.benefitItem}>
                <MaterialIcons name="check-circle" size={20} color={Colors.success} />
                <Text style={styles.benefitText}>{feature}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Subscription Plans */}
        <View style={styles.plansSection}>
          <Text style={styles.plansTitle}>Tariflar</Text>
          {SUBSCRIPTION_PLANS.map((plan) => (
            <SubscriptionCard
              key={plan.type}
              subscription={plan}
              isActive={user?.subscriptionType === plan.type}
              onSelect={() => handleSubscriptionChange(plan.type)}
            />
          ))}
        </View>

        {/* FAQ Section */}
        <View style={styles.faqSection}>
          <Text style={styles.faqTitle}>Tez-tez so'raladigan savollar</Text>
          
          <View style={styles.faqItem}>
            <Text style={styles.faqQuestion}>Premium obuna qanday ishlaydi?</Text>
            <Text style={styles.faqAnswer}>
              Premium obuna sizga barcha manga katalogiga kirish, reklamasiz o'qish va boshqa imtiyozlarni beradi.
            </Text>
          </View>

          <View style={styles.faqItem}>
            <Text style={styles.faqQuestion}>Obunani bekor qilish mumkinmi?</Text>
            <Text style={styles.faqAnswer}>
              Ha, obunani istalgan vaqt bekor qilishingiz mumkin. Obuna muddati tugagunga qadar premium xususiyatlardan foydalanishda davom etasiz.
            </Text>
          </View>

          <View style={styles.faqItem}>
            <Text style={styles.faqQuestion}>Offline o'qish qanday ishlaydi?</Text>
            <Text style={styles.faqAnswer}>
              Premium obuna bilan mangalarni yuklab olib, internet aloqasisiz o'qishingiz mumkin.
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.alertOverlay}>
            <View style={styles.alertContainer}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.surface,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  currentPlan: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.background,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  currentPlanText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 4,
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  benefitsSection: {
    marginVertical: 20,
  },
  benefitsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  benefitsList: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  benefitText: {
    fontSize: 16,
    color: Colors.text,
    marginLeft: 12,
    flex: 1,
  },
  plansSection: {
    marginBottom: 20,
  },
  plansTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  faqSection: {
    marginTop: 20,
  },
  faqTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  faqItem: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  faqAnswer: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
  // Web Alert Styles
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: Colors.text,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: Colors.text,
  },
  alertButton: {
    backgroundColor: Colors.primary,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});