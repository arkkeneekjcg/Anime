import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  Alert,
  Modal,
  Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../hooks/useAuth';
import { useManga } from '../../hooks/useManga';
import { Colors } from '../../constants';
import { AdminStats } from '../../types';

export default function AdminScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { mangas, deleteManga, getAdminStats } = useManga();
  
  const [stats, setStats] = useState<AdminStats>({
    totalMangas: 0,
    totalUsers: 0,
    premiumUsers: 0,
    totalChapters: 0
  });
  
  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
    onCancel?: () => void;
    showCancel?: boolean;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void, onCancel?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ 
        visible: true, 
        title, 
        message, 
        onOk, 
        onCancel,
        showCancel: !!onCancel 
      });
    } else {
      const buttons = onCancel 
        ? [
            { text: 'Bekor qilish', onPress: onCancel },
            { text: 'OK', onPress: onOk }
          ]
        : [{ text: 'OK', onPress: onOk }];
      Alert.alert(title, message, buttons);
    }
  };

  useEffect(() => {
    if (user?.isAdmin) {
      loadStats();
    }
  }, [user, mangas]);

  const loadStats = async () => {
    const adminStats = await getAdminStats();
    setStats(adminStats);
  };

  const handleDeleteManga = (mangaId: string, mangaTitle: string) => {
    showWebAlert(
      'Mangani o\'chirish',
      `"${mangaTitle}" mangasini o\'chirishni xohlaysizmi? Bu amal qaytarib bo\'lmaydi.`,
      async () => {
        const success = await deleteManga(mangaId);
        if (success) {
          showWebAlert('Muvaffaqiyat', 'Manga muvaffaqiyatli o\'chirildi');
        } else {
          showWebAlert('Xatolik', 'Mangani o\'chirishda xatolik yuz berdi');
        }
      },
      () => {} // Cancel handler
    );
  };

  if (!user?.isAdmin) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.notAdminContainer}>
          <MaterialIcons name="block" size={64} color={Colors.error} />
          <Text style={styles.notAdminTitle}>Kirish taqiqlangan</Text>
          <Text style={styles.notAdminText}>
            Bu sahifa faqat admin foydalanuvchilar uchun
          </Text>
        </View>
      </View>
    );
  }

  const statsCards = [
    {
      title: 'Jami mangalar',
      value: stats.totalMangas,
      icon: 'library-books',
      color: Colors.primary
    },
    {
      title: 'Jami foydalanuvchilar',
      value: stats.totalUsers,
      icon: 'people',
      color: Colors.secondary
    },
    {
      title: 'Premium foydalanuvchilar',
      value: stats.premiumUsers,
      icon: 'star',
      color: Colors.premium
    },
    {
      title: 'Jami chapterlar',
      value: stats.totalChapters,
      icon: 'description',
      color: Colors.success
    }
  ];

  const adminActions = [
    {
      title: 'Yangi manga qo\'shish',
      description: 'Yangi manga va uning chapterlarini yuklash',
      icon: 'add-circle',
      color: Colors.success,
      onPress: () => router.push('/admin/add-manga')
    },
    {
      title: 'Foydalanuvchilarni boshqarish',
      description: 'Foydalanuvchi hisoblarini ko\'rish va boshqarish',
      icon: 'manage-accounts',
      color: Colors.secondary,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    },
    {
      title: 'Obuna statistikasi',
      description: 'Premium obuna va daromad hisobotlari',
      icon: 'analytics',
      color: Colors.warning,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    },
    {
      title: 'Admin qo\'shish',
      description: 'Yangi admin foydalanuvchi qo\'shish',
      icon: 'admin-panel-settings',
      color: Colors.admin,
      onPress: () => showWebAlert('Xabar', 'Bu funksiya hali ishlab chiqilmoqda')
    }
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Admin Panel</Text>
        <View style={styles.adminBadge}>
          <MaterialIcons name="admin-panel-settings" size={20} color={Colors.admin} />
          <Text style={styles.adminBadgeText}>Admin</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Statistics */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Statistika</Text>
          <View style={styles.statsGrid}>
            {statsCards.map((stat, index) => (
              <View key={index} style={[styles.statCard, { borderLeftColor: stat.color }]}>
                <View style={styles.statHeader}>
                  <MaterialIcons name={stat.icon as any} size={24} color={stat.color} />
                  <Text style={styles.statValue}>{stat.value}</Text>
                </View>
                <Text style={styles.statTitle}>{stat.title}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.actionsSection}>
          <Text style={styles.sectionTitle}>Tezkor amallar</Text>
          {adminActions.map((action, index) => (
            <TouchableOpacity key={index} style={styles.actionCard} onPress={action.onPress}>
              <View style={styles.actionLeft}>
                <View style={[styles.actionIcon, { backgroundColor: action.color + '20' }]}>
                  <MaterialIcons name={action.icon as any} size={24} color={action.color} />
                </View>
                <View style={styles.actionText}>
                  <Text style={styles.actionTitle}>{action.title}</Text>
                  <Text style={styles.actionDescription}>{action.description}</Text>
                </View>
              </View>
              <MaterialIcons name="chevron-right" size={24} color={Colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Manga Management */}
        <View style={styles.mangaSection}>
          <Text style={styles.sectionTitle}>Manga boshqaruvi</Text>
          {mangas.map((manga) => (
            <View key={manga.id} style={styles.mangaItem}>
              <View style={styles.mangaInfo}>
                <Text style={styles.mangaTitle}>{manga.title}</Text>
                <Text style={styles.mangaDetails}>
                  {manga.chapters.length} bob • {manga.author}
                  {manga.isPremium && ' • Premium'}
                </Text>
              </View>
              <View style={styles.mangaActions}>
                <TouchableOpacity 
                  style={styles.actionButton}
                  onPress={() => router.push(`/manga/${manga.id}`)}
                >
                  <MaterialIcons name="visibility" size={20} color={Colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.actionButton}
                  onPress={() => handleDeleteManga(manga.id, manga.title)}
                >
                  <MaterialIcons name="delete" size={20} color={Colors.error} />
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.alertOverlay}>
            <View style={styles.alertContainer}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <View style={styles.alertButtons}>
                {alertConfig.showCancel && (
                  <TouchableOpacity 
                    style={[styles.alertButton, styles.cancelButton]}
                    onPress={() => {
                      alertConfig.onCancel?.();
                      setAlertConfig(prev => ({ ...prev, visible: false }));
                    }}
                  >
                    <Text style={styles.cancelButtonText}>Bekor qilish</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.admin,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.surface,
  },
  adminBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  adminBadgeText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.admin,
    marginLeft: 4,
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  statsSection: {
    marginVertical: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  statTitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  actionsSection: {
    marginBottom: 20,
  },
  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  actionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  actionText: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  actionDescription: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  mangaSection: {
    marginBottom: 20,
  },
  mangaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  mangaInfo: {
    flex: 1,
  },
  mangaTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  mangaDetails: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  mangaActions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  notAdminContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  notAdminTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 16,
    textAlign: 'center',
  },
  notAdminText: {
    fontSize: 16,
    color: Colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
  // Web Alert Styles
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: Colors.text,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: Colors.text,
  },
  alertButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  alertButton: {
    backgroundColor: Colors.primary,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
    marginLeft: 8,
    minWidth: 80,
  },
  cancelButton: {
    backgroundColor: Colors.textSecondary,
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  cancelButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});