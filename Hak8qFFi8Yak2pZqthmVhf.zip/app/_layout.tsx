import React from 'react';
import { Stack } from 'expo-router';
import { AuthProvider } from '../contexts/AuthContext';
import { MangaProvider } from '../contexts/MangaContext';

export default function RootLayout() {
  return (
    <AuthProvider>
      <MangaProvider>
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="login" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen 
            name="manga/[id]" 
            options={{ 
              headerShown: true,
              title: '',
              headerStyle: { backgroundColor: '#FF6B6B' },
              headerTintColor: '#fff'
            }} 
          />
          <Stack.Screen 
            name="reader/[mangaId]/[chapter]"
            options={{ 
              headerShown: false,
              presentation: 'fullScreenModal'
            }}
          />
          <Stack.Screen 
            name="admin/add-manga"
            options={{
              headerShown: true,
              title: 'Yangi Manga',
              headerStyle: { backgroundColor: '#E67E22' },
              headerTintColor: '#fff'
            }}
          />
        </Stack>
      </MangaProvider>
    </AuthProvider>
  );
}